<?php $__env->startSection('mainContent'); ?>

    <!-- Main Content -->
    <div id="content">

        <!-- Topbar -->
        <?php echo $__env->make('layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->

            <?php echo $__env->yieldContent('content'); ?>

        <!-- End Page Content -->

    </div>
    <!-- End of Main Content -->

    <!-- Footer -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- End of Footer -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>