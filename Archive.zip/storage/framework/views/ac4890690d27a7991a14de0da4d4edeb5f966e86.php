<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <!-- Nested Row within Card Body -->
        <div class="col px-5 py-3">
            <div class="card o-hidden border-0 shadow-lg ">
                <?php echo $__env->yieldContent('cardContent'); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainContent', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>