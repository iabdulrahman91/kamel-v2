

<!-- Page level plugins -->
<script src="<?php echo e(asset('customized/vendor/chart.js/Chart.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('customized/js/demo/chart-area-demo.js')); ?>"></script>
<script src="<?php echo e(asset('customized/js/demo/chart-pie-demo.js')); ?>"></script>
<script src="<?php echo e(asset('customized/js/demo/chart-bar-demo.js')); ?>"></script>