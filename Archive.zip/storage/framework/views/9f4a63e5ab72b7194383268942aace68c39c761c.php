<?php $__env->startSection('content'); ?>
    <div class="form mx-md-5">
        <div class="form-row m-3">
            <div class="form-group col-md-3">
                <select id="inputState" class="form-control">
                    <option selected>State...</option>
                    <option>...</option>
                </select>
            </div>
            <div class="form-group col-md-3">
                <select id="inputState" class="form-control">
                    <option selected>State...</option>
                    <option>...</option>
                </select>
            </div>
            <div class="form-group col-md-3">
                <select id="inputState" class="form-control">
                    <option selected>State...</option>
                    <option>...</option>
                </select>
            </div>
            <div class="form-group col-md-auto">
                <input class="btn btn-primary btn-user btn-block" type="submit" type="submit"
                       value="List this Item">
            </div>

        </div>
        <hr>
    </div>
    <div class="col mt-2">
        <?php echo $__env->make('listing.album', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainContent', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>