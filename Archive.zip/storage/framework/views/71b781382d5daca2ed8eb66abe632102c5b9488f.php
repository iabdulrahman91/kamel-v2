<?php $__env->startSection('content'); ?>
    <?php if(count($result)): ?>

        <table class="table">
            <thead class="thead-dark">
            <tr>
                <th scope="col">item name</th>
                <th scope="col">requester</th>
                <th scope="col">owener</th>
                <th scope="col">Start</th>
                <th scope="col">End</th>
                <th scope="col">cost</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($r['item']); ?></th>
                    <td><?php echo e($r['renter']); ?></td>
                    <td><?php echo e($r['owner']); ?></td>
                    <td><?php echo e($r['start']); ?></td>
                    <td><?php echo e($r['end']); ?></td>
                    <td>SAR <?php echo e($r['cost']); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>

        <div class="jumbotron text-center bg-light">
            <div class="jumbotron-heading h1">
                No Requests found
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainContent', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>