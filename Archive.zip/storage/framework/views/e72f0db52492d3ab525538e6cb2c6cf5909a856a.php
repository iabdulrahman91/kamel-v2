<?php $__env->startSection('content'); ?>
    <div class="container my-2">
        <a href="/listings/create" class=" btn btn-user bg-success text-white"><strong>List an Item here</strong></a>
    </div>
    <?php echo $__env->make('listing.album', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainContent', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>