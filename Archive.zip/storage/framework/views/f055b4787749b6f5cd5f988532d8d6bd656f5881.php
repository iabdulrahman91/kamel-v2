<?php if(count($listings)): ?>

    <table class="table">
        <thead class="thead-dark">
        <tr>
            <th scope="col">Owner</th>
            <th scope="col">Item</th>
            <th scope="col">Location</th>
            <th scope="col">Start</th>
            <th scope="col">End</th>
            <th scope="col">Price</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($listing->user->fname); ?></th>
                <td><?php echo e($listing->item); ?></td>
                <td><?php echo e($listing->location); ?></td>
                <td><?php echo e($listing->start); ?></td>
                <td><?php echo e($listing->end); ?></td>
                <td><?php echo e($listing->price); ?></td>
                <td> <a href="/listings/<?php echo e($listing->id); ?>" class="btn btn-secondary btn-lg active" role="button" aria-pressed="true">View</a> </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>

    <div class="jumbotron text-center bg-light">
        <div class="jumbotron-heading h1">
            No item listed
        </div>
    </div>
<?php endif; ?>
