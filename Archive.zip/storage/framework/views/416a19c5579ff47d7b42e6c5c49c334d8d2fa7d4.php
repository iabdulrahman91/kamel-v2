<?php $__env->startSection('cardContent'); ?>


    <div class="h3 text-center card-header">
        <?php echo e($listing->item); ?>

    </div>
    <div class="card-body">
        <div class="form-group">
            <?php if($errors->has('rentRequest_id')): ?>
                <div class="row justify-content-md-center">
                    <div class="col-md-5 badge-danger">

                        <strong><?php echo e($errors->first('rentRequest_id')); ?></strong>

                    </div>
                </div>
            <?php endif; ?>
        </div>
        <form class="user justify-content-center text-center" method="POST" action="/rentRequests">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="listing_id" value="<?php echo e($listing->id); ?>">
            <div class="form-group">
                <div class="col-md-auto">
                    <label for="start" class="h3"><?php echo e($listing->location); ?></label>
                </div>

            </div>

            <div class="form-group<?php echo e($errors->has('start') ? ' has-error' : ''); ?>">
                <div class="row justify-content-md-center">
                    <div class="col-md-6">
                        <label for="start" class="col-form-label">
                            Start Date This item is available from <?php echo e($listing->start); ?>

                        </label>
                        <input id="start" type="date" class="form-control form-control-user text-center" name="start"
                               value="<?php echo e(old('start')); ?>" required>
                        <?php if($errors->has('start')): ?>
                            <span class="help-block">
                                        <strong><?php echo e($errors->first('start')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="form-group<?php echo e($errors->has('end') ? ' has-error' : ''); ?>">
                <div class="row justify-content-md-center">
                    <div class="col-md-6">
                        <label for="start" class="col-form-label">
                            End Date This item is available until <?php echo e($listing->end); ?>

                        </label>
                        <input id="end" type="date" class="form-control form-control-user text-center" name="end"
                               value="<?php echo e(old('end')); ?>" onchange="cal()" required>
                        <?php if($errors->has('end')): ?>
                            <span class="help-block">
                                        <strong><?php echo e($errors->first('end')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="form-group<?php echo e($errors->has('end') ? ' has-error' : ''); ?>">
                <div class="row justify-content-md-center">
                    <div class="col-md-5">
                        <input id="numdays2" type="text" class="form-control form-control-user text-center"
                               name="numdays"
                               disabled="true">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <?php if($errors->has('listing_id')): ?>
                    <div class="row justify-content-md-center">
                        <div class="col-md-5 badge-danger">

                                    <strong><?php echo e($errors->first('listing_id')); ?></strong>

                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="form-group">
                <div class="row justify-content-md-center">
                    <div class="col-md-6">
                        <input class="btn btn-primary btn-user btn-block" type="submit" type="submit"
                               value="Request this item">
                        <a class="btn btn-outline-danger btn-user btn-block"
                           href="<?php echo e(redirect()->back()->getTargetUrl()); ?>" role="button">Cancel</a>
                    </div>
                </div>
            </div>
        </form>
    </div>

    
    <script type="text/javascript">
        function GetDays() {

            var end = new Date(document.getElementById("end").value);
            var start = new Date(document.getElementById("start").value);
            return parseFloat(((end - start) / (24 * 3600 * 1000)));
        }

        function cal() {
            if (document.getElementById("end")) {
                var days = GetDays();
                document.getElementById("numdays2").value = (days > 0) ? "Estimated Cost = SAR " + (days * parseFloat(<?php echo e($listing->price); ?>)) + " for " + days + " day/s " : "End date must be after start date.";
            }
        }

    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.card', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>