<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('customized/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('customized/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('customized/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('customized/js/sb-admin-2.min.js')); ?>"></script>