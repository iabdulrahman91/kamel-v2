<?php $__env->startSection('page'); ?>

    <!-- Navigation -->
    <?php echo $__env->make('guest.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Header -->
    
    <header class="bg-primary py-5 mb-5">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-lg-12">
                    <h1 class="display-4 text-white mt-5 mb-2">Welcome to <?php echo e(config('app.name', 'Kamel')); ?></h1>
                    <p class="lead mb-5 text-white-50">
                        Kamel allows you to rent product that might be not necessary to buy.
                        Nevertheless, Kamel make it easy for you to make money be lending your
                        item to others while you don't use them.
                    </p>
                    <a href="/login" class="btn btn-warning btn-lg my-2"> Login </a>
                    <a href="/register" class="btn btn-warning btn-lg my-2">New User</a>
                </div>
            </div>
        </div>
    </header>

    <!-- Page Content -->

        <?php echo $__env->make('listing.album', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- /.container -->

    <!-- Footer -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>