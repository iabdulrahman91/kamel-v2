{{--These are added for charts--}}

<!-- Page level plugins -->
<script src="{{ asset('customized/vendor/chart.js/Chart.min.js') }}"></script>

<!-- Page level custom scripts -->
<script src="{{ asset('customized/js/demo/chart-area-demo.js') }}"></script>
<script src="{{ asset('customized/js/demo/chart-pie-demo.js') }}"></script>
<script src="{{ asset('customized/js/demo/chart-bar-demo.js') }}"></script>